<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'FdHA1Q/kZv(v?*S?XVMo*w61:^CSXfrOp:7U;&N>(-^D|zW9l]wf(s#UQ1Sg57_?' );
define( 'SECURE_AUTH_KEY',   ')Djgx|*W]`!l?n#|KCJir8 WH*JVE.FWn^Zng@g+,/<wT#.nc9N:HdE$V~?}3fm<' );
define( 'LOGGED_IN_KEY',     'u3TVp_QAVDIBgqoi6Sb932ghj|hQ<9RAxN^5gZ8_1(csCj;w4d!#N(Hpfr9q$%,,' );
define( 'NONCE_KEY',         'f[,BX>*?C*O^8R@b0YYb;Q-3(b!sYQ@?:o6Of=OI;OcYJhY^3oeldJNfdYi:>!)z' );
define( 'AUTH_SALT',         'PJe{JeBM~Op#BwwfGYVCaEJ~3yU~ic%!_)N&KmMWOOoeB(tgptpg>|@]oO*g~E$0' );
define( 'SECURE_AUTH_SALT',  'DY:.`yF1fRPTofqLP%-_Ksm3N1B00uCErC1=6ObtW$[94XCltMo:A!/1w*b33`}n' );
define( 'LOGGED_IN_SALT',    'u>-+WHA&sU~BVbC~d1`[7If_rxh>?fWKEk w@zmVkE$Qos}Z/pudL{%m&kN<% j+' );
define( 'NONCE_SALT',        'z{w8+R6A A&4Y=Y  MR,fYF|x``$.l@e9L1MKx04E|2h(*s8[I@SLV?Kuiiz*;Py' );
define( 'WP_CACHE_KEY_SALT', 'xNm.n A>olEVF1HV0ID-7:%T`c@A5i%dSAwq;J?v= ;qY-VlXtTk?nuvc!,>*q;I' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
